<?php
include 'conn.php';
$branch_id ='';
$branch_name ='';
$branch_code='';
$address ='';

$sql = "INSERT INTO `branch`(`branch_id`, `branch_name`, `branch_code`, `address`) 
VALUES('$branch_id','$branch_name','$branch_code','$address')";
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");

if($result){
    echo "successfull";
}else{
    echo "unsuccessfull";
}

mysqli_close($conn);

?>
