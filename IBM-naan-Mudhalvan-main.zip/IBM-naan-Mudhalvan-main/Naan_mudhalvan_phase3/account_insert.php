<!-- insert data for Accounts -->
<?php
include 'conn.php';

$account_id='';
$account_type='';
$account_number='';
$current_balance='';
$date='';

$sql = "INSERT INTO `account`(`account_id`, `account_type`, `account_number`, `current_balance`, `date_opened`) 
VALUES('$account_id','$account_type','$account_number','$current_balance','$date')";
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");

if($result){
    echo "successfull";
}else{
    echo "unsuccessfull";
}

mysqli_close($conn);
?>

<!-- insert data for Accounts -->

