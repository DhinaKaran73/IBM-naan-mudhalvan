<!-- setting up the connection with the Database -->

<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "banking_sector";

$conn = mysqli_connect($servername, $username, $password, $database);

?>

<!-- setting up the connection with the Database -->
