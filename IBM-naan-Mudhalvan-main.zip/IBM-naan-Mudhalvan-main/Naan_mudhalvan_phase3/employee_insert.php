<!-- insert data for Employee -->
<?php
include 'conn.php';

$name ='';
$email ='';
$position ='';
$contact ='';
$address ='';

$sql = "INSERT INTO `employee`(`name`, `email`, `position`, `contact`, `address`) 
VALUES('$name','$email','$position','$contact','$address')";
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");

if($result){
    echo "successfull";
}else{
    echo "unsuccessfull";
}

mysqli_close($conn);

?>
<!-- insert data for Employee -->