<!-- insert data for Customer  -->
<?php
include 'conn.php';

$customer_id ='';
$customer_type ='';
$account_no ='';
$branch_id ='';
$email ='';

$sql = "INSERT INTO `customer`(`customer_Id`, `customer_type`, `account_no`, `branch_id`, `email`)
VALUES('$customer_id','$customer_type','$account_no','$branch_id','$email')";
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");

if($result){
    echo "successfull";
}else{
    echo "unsuccessfull";
}

mysqli_close($conn);

?>
<!-- insert data for Customer  -->
