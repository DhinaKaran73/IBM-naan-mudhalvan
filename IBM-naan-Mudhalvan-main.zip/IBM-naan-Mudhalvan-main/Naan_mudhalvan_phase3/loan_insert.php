<!-- insert data for Loan -->
<?php
include 'conn.php';

$loan_id ='';
$st_date ='';
$end_date ='';
$loan_type ='';
$loan_amount ='';
$user_id ='';


$sql = "INSERT INTO `loan`(`loan_id`, `start_date`, `end_date`, `loan_type`, `loan_amount`, `user_id`) VALUES
('$loan_id','$st_date','$end_date','$loan_type','$loan_amount','$user_id')";
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");

if($result){
    echo "successfull";
}else{
    echo "unsuccessfull";
}

mysqli_close($conn);
?>

<!-- insert data for Loan -->

